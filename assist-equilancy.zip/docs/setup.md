# Setup

## Intro

This document will detail the necessary steps to properly configure your environment.

## Packages

~~1. Selenium~~

1. Playwright
    - make sure to run `playwright install`
1. BeautifulSoup
